"use client"

import React, { useEffect, useRef, useState } from "react";
import Image from "next/image";
import LinkButton from "./LinkButton";

const InputMessage = ({onClick}) => {
  const [messageInput, setMessageInput] = useState("");
  const [isFocused, setIsFocused] = useState(true);
  const [isSend, setSend] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null); // Specify the type of the ref

  const handleSend = () => {
    setSend(true);
    setIsFocused(true)
    onClick(encodeURI(messageInput));
    setMessageInput("");
    setTimeout(() => {
      setSend(false)
    },200)
  }

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (isFocused && inputRef.current) {
        inputRef.current.focus(); // Focus on the input field if isFocused is true and inputRef is assigned
      }
    }, 300); // Delay the focus by 300 milliseconds

    return () => clearTimeout(timeoutId); // Cleanup the timeout on component unmount

  }, [isFocused, inputRef.current]); // Depend on inputRef.current for useEffect to trigger


  return (
    <div className="flex flex-row justify-center absolute bottom-0 w-full">
      <input
        type="text"
        className="w-2/3 mt-48 focus:mt-2 text-black lg:h-16 h-12 text-sm lg:text-xl md:h-14 focus:outline-none rounded-full bg-slate-300 border-gray-500 px-4" 
        placeholder="What are you looking for?"
        onChange={(event) => {setMessageInput(event.target.value)}}
        style={{ paddingRight: '100px' }}
        ref={inputRef}
        value={messageInput}
        onBlur={() => setIsFocused(false)}
        onFocus={() => setIsFocused(true)}
      />
      <div className="flex flex-row items-end gap-5 md:gap-3 -ml-24 md:-ml-20" style={{zIndex:1}}>
        <LinkButton />
        <button className="mb-4 " onClick={handleSend}>
          <Image
            src="/send_button.png"
            width={isSend ? 30 : 25}
            height={32}
            alt="send_button"
            className="h-4 md:h-6"
          />
        </button>
    </div>
    </div>
      
  );
  };
  
export default InputMessage;