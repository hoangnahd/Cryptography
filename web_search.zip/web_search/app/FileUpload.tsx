"use client"
import React, { ChangeEvent, useRef,useState } from 'react';
import Image from 'next/image';

interface FileUploadButtonProps {
  onChange: (file: File) => void;
}

const FileUpload: React.FC<FileUploadButtonProps> = ({ onChange, value }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [isClicked, setIsClicked] = useState(false);
  // Trigger file input when image is clicked
  const handleClick = () => {
    if (fileInputRef.current) {
      setIsClicked(true);
      setTimeout(() => {
        setIsClicked(false);
      }, 200);
      fileInputRef.current.click();
    }
  };

  // Handle file change
  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onChange(file);
    }
  };

  return (
    <div style={{ display: 'inline-block', position: 'relative' }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      { value? (
        <Image
          src="/plus.svg"
          width={isClicked ? 40 : (isHovered ? 45 : 40)}
          height={isClicked ? 40 : (isHovered ? 45 : 40)}
          alt="Upload icon"
          onClick={handleClick}
          style={{ cursor: 'pointer' }}
          className='h-7 md:h-10 lg:h-12'
        />
      ) : (
        <Image
          src="/link_button.png"
          width={isClicked ? 30 : 25}
          height={isClicked ? 30 : 25}
          alt="send_button"
          className="h-4 md:h-6 lg:h-7 mb-2 hover:cursor-pointer"
          onClick={handleClick}
        />
      )}
      
      <input
        type="file"
        onChange={handleFileChange}
        accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png"
        style={{ display: 'none' }}
        ref={fileInputRef}
      />
    </div>
  );
};

export default FileUpload;
