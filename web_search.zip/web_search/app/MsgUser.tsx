import Image from "next/image";


const MsgUser = ({ msg }) => {
    return (
        <div className="flex flex-row gap-2 justify-end">
            <div className=" bg-red-400 rounded-2xl p-2">
                {decodeURIComponent(msg)}
            </div>
            <div className="bg-zinc-800 w-10 ml-2 h-10 rounded-full">
                <Image
                    className="ml-2"
                    src="/user.webp"
                    width={25}
                    height={100}
                    alt="user"
                />
            </div>
        </div>
    )
}

export default MsgUser;