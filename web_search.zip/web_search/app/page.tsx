"use client"
import React, { useState } from "react";
import Image from "next/image";
import SearchInput from "./SearchInput";
import OpenDriveButton from "./OpenDriveButton";
import ChatBox from "./ChatBox";
import InputMessage from "./InputMessage";
import CopyNotice from "./CopyNotice";

export default function Home() {
  const [isClick, setClick] = useState(false)
  const [isClickCopy, setClickCopy] = useState(false);

  const [searchMessage, setSearchMessage] = useState('');
  const [start, setStart] = useState(false);

  
  const handleClick = ( value:string ) => {
    setClick(true);
    setStart(value != "");
    setSearchMessage(value);
  }
  const handleLeave = () => {
    setClick(false)
  }
  const handleClickCopy = () => {
    setClickCopy(true)
    setTimeout(() => {
      setClickCopy(false)
    },1000)
  }

  return (
    <div>
      <head>
        <style>
          {`
          @import url('https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap');
          @import url('https://fonts.googleapis.com/css2?family=Abril+Fatface&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');
          @import url('https://fonts.googleapis.com/css2?family=Euphoria+Script&display=swap')
          @import url('https://fonts.googleapis.com/css2?family=Carattere&family=Euphoria+Script&display=swap')
          `}
        </style>
      </head>
      <main className="relative">
        <div className="flex flex-col items-center">
          <div className="flex flex-col items-center relative" style={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 1 }}>
            <Image
              src="/back_ground.png"
              width={1500}
              height={200}
              alt="loading"
            />
            <div className=" absolute inset-0 flex items-center justify-center ">
              <div
                className="text-rainbow-animation lg:-mt-10 abril-fatface-regular font-bold text-[50px] md:text-[60px] lg:text-[50px] xl:text-[70px] hover:cursor-pointer"
                style={{ color: 'rgb(182, 91, 95)' }}
                onClick={handleLeave}
              >
                Insight Seeker
              </div>
            </div>
                {isClick?(
                    null
                ):(
                  <div className="flex flex-row -mb-10 absolute bottom-3 w-full justify-center lg:bottom-16 lg:space-y-5">
                  
                    <SearchInput onClick = {handleClick} />
                    <div className="flex justify-center items-center absolute inset-y-0 right-0 w-1/3 pl-10 pt-10 md:pl-12 md:pt-14 lg:pl-12">
                      <OpenDriveButton />
                    </div>
                  </div>
                )}
                
          </div>

          <div
            className="mt-[150px] md:mt-[300px] lg:mt-[310px] w-2/3 sm:w-4/5"
            style={{ position: "relative", zIndex: 0 }}
          >
            {isClickCopy && <CopyNotice />}
            
            
            <div className="flex justify-center">
              <div
                className="flex flex-col border border-gray-300 rounded-t-3xl p-4 w-2/3 overflow-y-auto mb-10 -mt-7 md:-mt-20n lg:-mt-9 h-[500px] lg:h-[420px]"
                style={{
                  backgroundColor: "rgb(255, 251, 241)",
                  maxHeight: "600px",
                  minWidth:"500px",
                  position: 'relative', // Add position relative to ChatBox container
                }}
              >
                <ChatBox onClick={handleClickCopy} start={start} message={searchMessage}/>
                {isClick && <InputMessage onClick={handleClick} />}

              </div>
            </div>     
          </div>
        </div>
      </main>
    </div>
  );
}
