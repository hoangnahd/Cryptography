import Image from "next/image";


const MsgBot = ({onClick, msg }) => {
    return (
        <div className="flex flex-row gap-2 justify-start">
            <div className="bg-zinc-800 w-10 ml-2 h-10 rounded-full">
                <Image
                    className="ml-2 mt-2"
                    src="/bot.webp"
                    width={25}
                    height={100}
                    alt="user"
                />
            </div>
            <div className="bg-zinc-800 p-2 rounded-2xl flex flex-row gap-7">
                <div
                    className=" "
                >
                    How can i help you?
                </div>
                <button className="-ml-10 pl-5" onClick={onClick}>
                    <Image 
                        src="/copy.png"
                        width={25}
                        height={100}
                        alt="copy image"
                    />
                </button>
            </div>
            
        </div>
    )
}

export default MsgBot;