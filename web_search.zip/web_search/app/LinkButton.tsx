import React, { useState } from 'react';
import FileUpload from './FileUpload';

const LinkButton = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null); // Specify the type of selectedFile
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const handleFileChange = (file: File | null) => { // Specify the type of the 'file' parameter
    setSelectedFile(file);
    if (file) {
      setImageUrl(URL.createObjectURL(file)); // Create object URL for the selected file
    } else {
      setImageUrl(null); // Clear the image URL when no file is selected
    }
  };
    return (
        <div>
            <div style={{ display: 'flex', alignItems: 'center' }}>
                {imageUrl && <img src={imageUrl} alt="Selected File" />} {/* Display the selected file's image */}
            </div>
            <FileUpload onChange={handleFileChange} value={false} />
        </div>
    );
}

export default LinkButton;