import Image from "next/image";



const CopyNotice = () => {
    return (
        <div className="absolute top-1/2 transform -translate-y-1/2 animate-slide-in">
            <div className=" -ml-48 -mb-5">
            <Image 
                src="/copy_board.svg"
                width={150}
                height={100}
                alt="copy clip board"
            />
            <span className="euphoria-script-regular absolute text-black italic font-bold -ml-32 text-2xl -mb-3 bottom-0 left-1/2 transform -translate-x-1/2">Copied!</span>
            </div>
        </div>
    )
}
export default CopyNotice;