"use client"
import { SetStateAction, useState } from 'react';
import Image from 'next/image';
import { relative } from 'path';

const SearchInput = ({ onClick }) => {
    const [value, setValue] = useState("");

    const [isHovered, setHovered] = useState(false);

    const handleButtonClick = () => {
        onClick(encodeURI(value));
    }
    const handleFocus = () => {
        setHovered(true);
    };
    const handleBlur = () => {
        setHovered(false)
    };
    return (
        <div className='roboto-medium w-full text-black md:text-xl lg:text-2xl flex justify-center flex-row relative'>
            <button className={`bg-white mt-1 ${isHovered? 'mt-2' : ''} h-auto`} onClick={handleButtonClick}>
                <Image
                    src="/search_button.jpg"
                    width={45}
                    height={10}
                    alt='search button'
                    className={`h-8 w-10 md:h-10 md:w-12 lg:h-12 lg:w-14 pt-1 pb-1 pl-1 pr-1 `}
                />
            </button>
            
            <input
                type="text"
                className={`w-2/3 mt-1 focus:mt-2 lg:h-16 h-8 md:h-14 focus:outline-none`}
                placeholder=" What are you looking for?"
                value={value}
                onChange={(event) => {setValue(event.target.value)}}
                onFocus={handleFocus}
                onBlur={handleBlur}      
            />
        </div>
            

        
    );
};

export default SearchInput;
