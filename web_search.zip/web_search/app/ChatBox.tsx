"use client"
import Image from "next/image";
import MsgUser from "./MsgUser";
import MsgBot from "./MsgBot";
import { useState, useEffect } from "react";


const ChatBox = ({ onClick, message, start}) => {
    
    return (
        <div className="flex flex-col gap-5">
            {start?(
                <div>
                    <MsgUser msg={message} />
                    <MsgBot msg={"How can i help you"} onClick={onClick} />
            </div>
            
                
            ):(
                <div>
                    <div className="flex flex-row gap-2 justify-end">
                        <div
                            className=" bg-red-400 w-1/3 rounded-2xl"
                        ></div>
                        <div className="bg-zinc-800 w-10 ml-2 h-10 rounded-full">
                            <Image
                                className="ml-2"
                                src="/user.webp"
                                width={25}
                                height={100}
                                alt="user"
                            />
                        </div>
                    </div>
                    <div className="flex flex-row gap-2 justify-start">
                        <div className="bg-zinc-800 w-10 ml-2 h-10 rounded-full">
                            <Image
                                className="ml-2 mt-2"
                                src="/bot.webp"
                                width={25}
                                height={100}
                                alt="user"
                            />
                        </div>
                        <div
                            className=" bg-zinc-800 w-1/3 rounded-2xl"
                        >
                        </div>

                        <button className="-ml-10 " onClick={onClick}>
                            <Image 
                                src="/copy.png"
                                width={25}
                                height={100}
                                alt="copy image"
                            />
                        </button>
                    </div>           
                </div>
            )}
            
            
        </div>
        
    );
}

export default ChatBox;